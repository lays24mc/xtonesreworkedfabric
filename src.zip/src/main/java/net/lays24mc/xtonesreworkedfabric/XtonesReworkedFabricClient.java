package net.lays24mc.xtonesreworkedfabric;

import net.fabricmc.api.ClientModInitializer;

public class XtonesReworkedFabricClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

    }
}
