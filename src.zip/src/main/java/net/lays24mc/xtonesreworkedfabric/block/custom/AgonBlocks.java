package net.lays24mc.xtonesreworkedfabric.block.custom;

import net.lays24mc.xtonesreworkedfabric.XtonesReworkedFabric;
import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class AgonBlocks {

    public static final Block AgonBlock = new XBlock();
    public static final Block AgonBlock1 = new XBlock();

    public static void registerAgonBlocks(){
        XtonesReworkedFabric.LOGGER.info("Registering AgonBlocks for " + XtonesReworkedFabric.MOD_ID);

        Registry.register(Registries.BLOCK, Identifier.of(XtonesReworkedFabric.MOD_ID, "agon_block_0"), AgonBlock);
        Registry.register(Registries.BLOCK, Identifier.of(XtonesReworkedFabric.MOD_ID, "agon_block_1"), AgonBlock1);

        Registry.register(Registries.ITEM, Identifier.of(XtonesReworkedFabric.MOD_ID, "agon_block_0"), new BlockItem(AgonBlock, new Item.Settings()));
        Registry.register(Registries.ITEM, Identifier.of(XtonesReworkedFabric.MOD_ID, "agon_block_1"), new BlockItem(AgonBlock1, new Item.Settings()));
    }
}
