package net.lays24mc.xtonesreworkedfabric.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.lays24mc.xtonesreworkedfabric.XtonesReworkedFabric;
import net.lays24mc.xtonesreworkedfabric.block.ModBlocks;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModItemGroups {

    public static final ItemGroup xtonesreworkedfabric_group = Registry.register(Registries.ITEM_GROUP,
            Identifier.of(XtonesReworkedFabric.MOD_ID, "xtonestab"),
            FabricItemGroup.builder().displayName(Text.translatable("itemgroup.xtonesreworkedfabric"))
                    .icon(() -> new ItemStack(ModBlocks.XTBlock)).entries((displayContext, entries) -> {
                        /*Entries in creative tab*/
                        // items
                        entries.add(ModItems.RUBY);

                        // blocks
                        entries.add(ModBlocks.XTBlock);

                    }).build());

    public static void registerItemGroup(){
        XtonesReworkedFabric.LOGGER.info("Registering item group for " + XtonesReworkedFabric.MOD_ID);
    }
}
